<main>
    <section id="SectionOneAddUser">
        <h1 id="TitleAddLogUser">Create Account</h1>
        <p id="t1--AddLogUser">Albready have an account ? <a id="a1--AddLogUser" href="#">Log in </a></p>


        <?php //$this->addModal("form", $form);?>

        <?php

        $file = "/Users/sambenitah/Documents/Projet Web/dontknow/Base Code/dontknow.zip";

        header('Content-Type: application/octet-stream');

        header('Content-Transfer-Encoding: Binary');

        header('Content-disposition: attachement; filename="'.basename($file).'"');

        echo readfile($file);


        ?>


    </section>
</main>


