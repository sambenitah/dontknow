<main>

    <div id="content">
        <section id="sectionOne">
            <div id="divOneSectionOne">
                <p id="mainTitle">DONT KN?W</p>
                <p id="textMainTitle">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt teidesior </p>
            </div>
        </section>
        <section class="sectionTwo">
            <div id="contentSectionTwo">
                <div id="divOneContentSectionTwo">

                    <p id="textOneSectionTwo" >Choisie par les meilleurs du<br> monde, la plateforme<br> idk donne aux<br> personnes créatives les moyens<br>de réussir.</p>
                    <a class="t-SectionTwo" id="t1-SectionTwo" href="#">Photographes</a>
                    <a class="t-SectionTwo" id="t2-SectionTwo" href="#">Restaurants</a>
                    <a class="t-SectionTwo" id="t3-SectionTwo" href="#">Musiciens</a>
                    <a class="t-SectionTwo" id="t4-SectionTwo" href="#">Startup</a>
                    <a class="t-SectionTwo" id="t5-SectionTwo" href="#">Stylistes</a>
                    <a class="t-SectionTwo" id="t6-SectionTwo" href="#">Entrepreneurs</a>
                    <a class="t2-SectionTwo" id="t7-SectionTwo" href="#">Voir tous nos templates</a>

                </div>

                <div class="divTwoContentSectionTwo" >

                </div>
            </div>
        </section>
        <section class="sectionThree">
            <div id="contentSectionThree">
                <div id="divOneContentSectionThree">
                    <p  id="t1-SectionThree">Outils Marketing</p>
                    <p  id="t2-SectionThree">Engagez et développez votre audience.</p>
                    <p  id="t3-SectionThree">Engagez votre audience à l’aide de notre gamme complète d’outils de marketing : recherche, réseaux sociaux et campagnes e-mail Squarespace. Créer une puissante stratégie de communication n’a jamais été aussi facile.</p>
                    <a  id="t4-SectionThree" href="#">En savoir plus</a>
                </div>
                <div id="divTwoContentSectionThree">
                    <div id="imgDivTwoContentSectionThree">

                    </div>
                </div>
            </div>
        </section>
        <section class="sectionFour">
            <div id="contentSectionFour">
                <div id="divOneContentSectionFour">
                    <p  id="t1-SectionFour">PLATEFORME TOUT-EN-UN</p>
                    <p  id="t2-SectionFour">Nous sommes à vos cotés</p>
                    <p  id="t3-SectionFour">Considérez ITD. comme votre service web personnel, avec un hébergement gratuit et illimité, une sécurité haut de gamme, une infrastructure de niveau professionnel et une assistance 24 heures sur 24. Notre service client est à votre disposition pour une assistance personnalisée par e-mail ou par messagerie instantanée. Vous pouvez également participer à un webinaire en direct. Contactez-nous à tout moment : nous sommes disponibles 24 h/24 et 7 j/7.</p>
                    <a  id="t4-SectionFour" href="#">En savoir plus</a>
                </div>
                <div id="divTwoContentSectionFour">
                    <div id="imgDivTwoContentSectionFour">

                    </div>
                </div>
            </div>
        </section>
    </div>
</main>


