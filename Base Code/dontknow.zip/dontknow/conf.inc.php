<?php
define("DBUSER", "root");
define("DBHOST", "database");
define("DBNAME", "dontknow");
define("DBPWD", "password");
define("DBDRIVER", "mysql");