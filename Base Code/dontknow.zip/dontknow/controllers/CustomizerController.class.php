<?php

Class CustomizerController{

    public function defaultAction(){
        $v = new View("customizer", "admin");
    }

}